var searchData=
[
  ['darbas_2ecpp_0',['Darbas.cpp',['../_darbas_8cpp.html',1,'']]]
];
