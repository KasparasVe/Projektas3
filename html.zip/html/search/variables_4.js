var searchData=
[
  ['skaiciavimas_0',['skaiciavimas',['../structstudentas.html#a3431c6dd3ba5186bb61a09f05d679199',1,'studentas']]]
];
