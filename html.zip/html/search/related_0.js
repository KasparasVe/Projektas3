var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_studentas.html#a26ac513d532bcd006bc6e2f40d44fc61',1,'Studentas']]],
  ['operator_3d_3d_1',['operator==',['../class_studentas.html#a0954b0dec2256d23b2f42919e82c2b01',1,'Studentas']]]
];
