var searchData=
[
  ['egzam_0',['egzam',['../structstudentas.html#a7fa4c3fbb9fe65db6cc4ea660023b013',1,'studentas']]]
];
