var searchData=
[
  ['create_5ffile_0',['create_file',['../_libas_8cpp.html#a090dc83134d39d9ca7373fb4c17f93b4',1,'create_file(string name, float sk):&#160;Libas.cpp'],['../_libas_8h.html#a090dc83134d39d9ca7373fb4c17f93b4',1,'create_file(string name, float sk):&#160;Libas.cpp']]]
];
